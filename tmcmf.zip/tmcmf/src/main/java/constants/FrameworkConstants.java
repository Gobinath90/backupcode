package constants;

import java.io.File;

public class FrameworkConstants {

	private FrameworkConstants() {
	}

	public static final String TEST_DATA_XLSX_FILE = "testdata/testData.xlsx";
	public static final String ACTIVE_PAGE_LOADED = "true";
	public static final double WAIT_SLEEP_STEP = 0;
	public static final long WAIT_EXPLICIT = 10;
	public static final long WAIT_PAGE_LOADED = 0;
	public static final String BROWSER = "chrome";

	public static final String ICON_BROWSER_PREFIX = "<i class=\"fa fa-";
	public static final String ICON_BROWSER_SUFFIX = "\" aria-hidden=\"true\"></i>";

	public static final String ICON_BROWSER_CHROME = "chrome";
	public static final String ICON_BROWSER_OPERA = "opera";
	public static final String ICON_BROWSER_EDGE = "edge";
	public static final String ICON_BROWSER_FIREFOX = "firefox";
	public static final String ICON_BROWSER_SAFARI = "safari";

	public static final String ICON_OS_WINDOWS = "<i class='fa fa-windows' ></i>";
	public static final String ICON_OS_MAC = "<i class='fa fa-apple' ></i>";
	public static final String ICON_OS_LINUX = "<i class='fa fa-linux' ></i>";
	
	
	public static final String ICON_SMILEY_PASS = "<i class='fa fa-smile-o' style='font-size:24px'></i>";
	public static final String ICON_SMILEY_SKIP = "<i class=\"fas fa-frown-open\"></i>";
	public static final String ICON_SMILEY_FAIL = "<i class='fa fa-frown-o' style='font-size:24px'></i>";
	public static final String ICON_BUG = "<i class='fa fa-bug' ></i>";
	
	
	public static final String PROJECT_PATH = getCurrentDir();
	public static final String REPORT_TITLE = "Report | Automation Framework Selenium | Anh Tester";

	public static final String EXTENT_REPORT_NAME = "ExtentReports";
	public static final String AUTHOR = "Gobinath";

	public static final String EXTENT_REPORT_FOLDER = "reports/ExtentReports";
	public static final String EXTENT_REPORT_FOLDER_PATH = PROJECT_PATH + EXTENT_REPORT_FOLDER;
	public static final String EXTENT_REPORT_FILE_NAME = EXTENT_REPORT_NAME + ".html";
	public static String EXTENT_REPORT_FILE_PATH = EXTENT_REPORT_FOLDER_PATH + File.separator + EXTENT_REPORT_FILE_NAME;

	public static final String OVERRIDE_REPORTS = "no";

	public static final String YES = "yes";
	public static final String NO = "no";
	public static final String url = "https://devcms.surgeonreview.net:4000/";
	public static final String ICON_Navigate_Right = "<i class='fa fa-arrow-circle-right' ></i>";
    public static final String BOLD_START = "<b>";
    public static final String BOLD_END = "</b>";


	public static final String OPEN_REPORTS_AFTER_EXECUTION = "no";
	public static final String RETRY_TEST_FAIL = "1";
	public static final String SCREENSHOT_ALL_STEPS = "YES";

	public static String getCurrentDir() {
		String current = System.getProperty("user.dir") + File.separator;
		return current;
	}
}
