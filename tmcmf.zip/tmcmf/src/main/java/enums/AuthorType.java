package enums;

public enum AuthorType {
    Gobinath
}
