package enums;

public enum Browser {

	CHROME, EDGE, FIREFOX
}
