package utils;

import static constants.FrameworkConstants.EXTENT_REPORT_FILE_NAME;
import static constants.FrameworkConstants.EXTENT_REPORT_FOLDER_PATH;
import static constants.FrameworkConstants.NO;
import static constants.FrameworkConstants.OPEN_REPORTS_AFTER_EXECUTION;
import static constants.FrameworkConstants.OVERRIDE_REPORTS;
import static constants.FrameworkConstants.YES;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

public class ReportUtils {
	 private ReportUtils() {
	        
	    }

	    public static String createExtentReportPath() {
	        String link = "";
	        if (OVERRIDE_REPORTS.trim().equals(NO)) {
	            System.out.println("OVERRIDE_REPORTS = " + OVERRIDE_REPORTS);
	            link = EXTENT_REPORT_FOLDER_PATH + File.separator + DateUtils.getCurrentDate() + "_"
	                    + EXTENT_REPORT_FILE_NAME;
	            System.out.println("Created link report: " + link);
	            return link;
	        } else {
	            System.out.println("OVERRIDE_REPORTS = " + OVERRIDE_REPORTS);
	            link = EXTENT_REPORT_FOLDER_PATH + File.separator + EXTENT_REPORT_FILE_NAME;
	            System.out.println("Created link report: " + link);
	            return link;
	        }
	    }

	    public static void openReports(String linkReport) throws IOException {
	        if (OPEN_REPORTS_AFTER_EXECUTION.trim().equalsIgnoreCase(YES)) {
	            
	                Desktop.getDesktop().browse(new File(linkReport).toURI());
	            
	        }
	    }
}
