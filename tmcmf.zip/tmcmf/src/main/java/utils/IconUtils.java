package utils;

import static constants.FrameworkConstants.ICON_BROWSER_CHROME;
import static constants.FrameworkConstants.ICON_BROWSER_EDGE;
import static constants.FrameworkConstants.ICON_BROWSER_FIREFOX;
import static constants.FrameworkConstants.ICON_BROWSER_PREFIX;
import static constants.FrameworkConstants.ICON_BROWSER_SUFFIX;
import static constants.FrameworkConstants.ICON_OS_LINUX;
import static constants.FrameworkConstants.ICON_OS_MAC;
import static constants.FrameworkConstants.ICON_OS_WINDOWS;

public class IconUtils {
	private IconUtils() {
		super();
	}

	public static String getBrowserIcon() {
		String browserInLowerCase = BrowserInfoUtils.getBrowserInfo().toLowerCase();
		if (browserInLowerCase.contains(ICON_BROWSER_CHROME)) {
			return ICON_BROWSER_PREFIX + ICON_BROWSER_CHROME + ICON_BROWSER_SUFFIX;
		} else if (browserInLowerCase.contains(ICON_BROWSER_EDGE)) {
			return ICON_BROWSER_PREFIX + ICON_BROWSER_EDGE + ICON_BROWSER_SUFFIX;
		} else if (browserInLowerCase.contains(ICON_BROWSER_FIREFOX)) {
			return ICON_BROWSER_PREFIX + ICON_BROWSER_FIREFOX + ICON_BROWSER_SUFFIX;
		} else {
			return BrowserInfoUtils.getBrowserInfo();
		}
	}

	public static String getOSIcon() {

		String operationSystem = BrowserInfoUtils.getOSInfo().toLowerCase();
		if (operationSystem.contains("win")) {
			return ICON_OS_WINDOWS;
		} else if (operationSystem.contains("nix") || operationSystem.contains("nux")
				|| operationSystem.contains("aix")) {
			return ICON_OS_LINUX;
		} else if (operationSystem.contains("mac")) {
			return ICON_OS_MAC;
		}
		return operationSystem;
	}
}
