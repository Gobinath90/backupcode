package driver;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import report.ExtentReportManager;

public class DriverManager {
	private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

	private DriverManager() {
		super();
	}

	public static WebDriver getDriver() {
		return driverThreadLocal.get();
	}

	public static void setDriver(WebDriver driver) {
		DriverManager.driverThreadLocal.set(driver);
	}

	public static void quitDriver() {
		if (DriverManager.getDriver() != null) {
			try {
				ExtentReportManager.flushReports();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			DriverManager.getDriver().quit();

			driverThreadLocal.remove();
		}
	}
}
