package helpers;

public class PropertiesHelpers {

	public static void loadAllFiles() {
		// TODO Auto-generated method stub
		
	}

}
