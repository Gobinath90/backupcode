package keywords;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import constants.FrameworkConstants;
import driver.DriverManager;
import report.ExtentReportManager;
import report.ExtentTestManager;

public class WebUI {
	
	public static void acceptAlert() {
        sleep(FrameworkConstants.WAIT_SLEEP_STEP);
        DriverManager.getDriver().switchTo().alert().accept();
        ExtentReportManager.info("Click Accept on Alert.");
    }

	public static boolean verifyElementClickable(By by) {
		smartWait();

		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			wait.until(ExpectedConditions.elementToBeClickable(by));
			if (ExtentTestManager.getExtentTest() != null) {
				ExtentReportManager.info("Verify element clickable " + by);
			}
			return true;
		} catch (Exception e) {
			Assert.fail("FAILED. Element not clickable " + by);
			return false;
		}
	}

	public static boolean verifyElementPresent(By by, String elementName) {
		smartWait();

		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			wait.until(ExpectedConditions.presenceOfElementLocated(by));
			if (ExtentTestManager.getExtentTest() != null) {
				ExtentReportManager.info("Verify element present " + elementName);
			}
			return true;
		} catch (Exception e) {
			Assert.fail("The element does NOT present. " + e.getMessage());
			return false;
		}
	}

	public static boolean verifyElementNotPresent(By by) {
		smartWait();

		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			wait.until(ExpectedConditions.presenceOfElementLocated(by));
			Assert.fail("The element presents. " + by);
			return false;
		} catch (Exception e) {
			return true;
		}
	}

	public static void logConsole(@Nullable Object object) {
		System.out.println(object);
	}

	public static void sleep(double second) {
		try {
			Thread.sleep((long) (second * 1000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static WebElement waitForElementClickable(By by) {
		smartWait();

		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			return wait.until(ExpectedConditions.elementToBeClickable(getWebElement(by)));
		} catch (Throwable error) {
			Assert.fail("Timeout waiting for the element ready to click. " + by.toString());

		}
		return null;
	}

	public static void Click(By by, String elementName) {
		waitForElementClickable(by).click();
		if (ExtentTestManager.getExtentTest() != null) {

			ExtentReportManager.pass("<b>" + elementName + "</b> is clicked");
		}
	}

	protected WebElement findElement(By by) {
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(10));
		return wait.until(ExpectedConditions.presenceOfElementLocated(by));
	}

	public static void smartWait() {
		if (FrameworkConstants.ACTIVE_PAGE_LOADED.trim().toLowerCase().equals("true")) {
			waitForPageLoaded();
		}
		sleep(FrameworkConstants.WAIT_SLEEP_STEP);
	}

	public static boolean verifyElementChecked(By by, String message) {
		smartWait();
		waitForElementVisible(by);

		boolean checked = getWebElement(by).isSelected();

		if (checked == true) {
			return true;
		} else {
			Assert.assertTrue(false, message);
			return false;
		}
	}

	public static WebElement getWebElement(By by) {
		return DriverManager.getDriver().findElement(by);
	}

	public static WebElement waitForElementVisible(By by) {
		smartWait();
		waitForElementPresent(by);

		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			boolean check = isElementVisible(by, 1);
			if (check == true) {
				return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			} else {
				scrollToElementAtBottom(by);
				return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			}
		} catch (Throwable error) {
			// LogUtils.error("Timeout waiting for the element Visible. " + by.toString());
			Assert.fail("Timeout waiting for the element Visible. " + by.toString());
		}
		return null;
	}

	public static WebElement waitForElementPresent(By by) {
		smartWait();

		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			return wait.until(ExpectedConditions.presenceOfElementLocated(by));
		} catch (Throwable error) {
			// LogUtils.error("Element not exist. " + by.toString());
			Assert.fail("Element not exist. " + by.toString());
		}
		return null;
	}

	public static boolean isElementVisible(By by, int timeout) {
		smartWait();

		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(), Duration.ofSeconds(timeout));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
			// LogUtils.info("Verify element visible " + by);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public static void scrollToElementAtBottom(By by) {
		smartWait();

		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript("arguments[0].scrollIntoView(false);", getWebElement(by));
		// LogUtils.info("Scroll to element " + by);
	}

	public static void waitForPageLoaded() {
		WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
				Duration.ofSeconds(FrameworkConstants.WAIT_PAGE_LOADED), Duration.ofMillis(500));
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();

		// wait for Javascript to loaded
		ExpectedCondition<Boolean> jsLoad = driver -> ((JavascriptExecutor) driver)
				.executeScript("return document.readyState").toString().equals("complete");

		// Get JS is Ready
		boolean jsReady = js.executeScript("return document.readyState").toString().equals("complete");

		// Wait Javascript until it is Ready!
		if (!jsReady) {
			// LogUtils.info("Javascript in NOT Ready!");
			// Wait for Javascript to load
			try {
				wait.until(jsLoad);
			} catch (Throwable error) {
				error.printStackTrace();
				Assert.fail("Timeout waiting for page load. (" + FrameworkConstants.WAIT_PAGE_LOADED + "s)");
			}
		}
	}

	/*
	 * 
	 * 
	 * 
	 */

	public static String getAttributeElement(By by, String attributeName) {
		smartWait();
		return waitForElementVisible(by).getAttribute(attributeName);
	}

	public static List<WebElement> getWebElements(By by) {
		return DriverManager.getDriver().findElements(by);
	}

	public static List<String> getListElementsText(By by, String elementName, boolean logToExtentReport,
			String expectedTitle) {
		smartWait();
		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));

			List<WebElement> listElement = getWebElements(by);
			List<String> listText = new ArrayList<>();
			//System.out.println("Number of " + elementType + ": " + listElement.size());
			//ExtentReportManager.info("Number of " + elementName + ": " + listElement.size());

			for (WebElement e : listElement) {
				String elementText = e.getText();
				listText.add(elementText);
				//System.out.println(elementType + ": " + e.getText());
				if (logToExtentReport) {
					ExtentReportManager.info("<b>" + elementName + "</b>" + ": " + e.getText());
				}
				// Assertion: Check if element text contains expected title
				try {
					Assert.assertTrue(elementText.contains(expectedTitle),
							"Element text does not contain expected title: " + expectedTitle);
				} catch (AssertionError assertionError) {
					if (logToExtentReport) {
						ExtentReportManager.fail("Assertion failed: " + assertionError.getMessage());
					}
					throw assertionError; // Rethrow the assertion error to fail the test
				}
			}

			return listText;
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;

	}
	public static void handleWindows(String elementName) throws InterruptedException {
		String mainWindowHandle = DriverManager.getDriver().getWindowHandle();
		for (String handle : DriverManager.getDriver().getWindowHandles()) {
			if (!handle.equals(mainWindowHandle)) {
				DriverManager.getDriver().switchTo().window(handle);
				System.out.println("Switched to Tab: " + elementName + ": " + handle);
				break;
			}
		}
		Thread.sleep(3000); // Consider using explicit wait instead
	}

	public static void closeOriginalWindow() {
		DriverManager.getDriver().close();
	}

	public static void switchBackToMainWindow(String elementName) {
		DriverManager.getDriver().switchTo().window(DriverManager.getDriver().getWindowHandles().iterator().next());
		System.out.println("Switched back to Main Tab: " + elementName);
	}
	
	public static String getCommaSeparatedElementText(By by, String elementName, boolean logToExtentReport,
			String expectedTitle) {
		smartWait();
		try {
			WebDriverWait wait = new WebDriverWait(DriverManager.getDriver(),
					Duration.ofSeconds(FrameworkConstants.WAIT_EXPLICIT), Duration.ofMillis(500));
			wait.until(ExpectedConditions.visibilityOfElementLocated(by));

			List<WebElement> listElement = getWebElements(by);
			StringBuilder commaSeparatedText = new StringBuilder();
			StringBuilder logMessage = new StringBuilder();

			for (int i = 0; i < listElement.size(); i++) {
				WebElement e = listElement.get(i);
				String elementText = e.getText();
				commaSeparatedText.append(elementText);
				if (i < listElement.size() - 1) {
					commaSeparatedText.append(", ");
				}

				if (logToExtentReport) {
					if (i > 0) {
						logMessage.append(", ");
					}
					logMessage.append("<b>" + elementName + "</b>: " + elementText);
				}

				// Assertion: Check if element text contains expected title
				try {
					Assert.assertTrue(elementText.contains(expectedTitle),
							"Element text does not contain expected title: " + expectedTitle);
				} catch (AssertionError assertionError) {
					if (logToExtentReport) {
						ExtentReportManager.fail("Assertion failed: " + assertionError.getMessage());
					}
					throw assertionError; // Rethrow the assertion error to fail the test
				}
			}
			String logMessageString = logMessage.toString();
			if (logToExtentReport) {
				ExtentReportManager.info(logMessageString);
			}

			return commaSeparatedText.toString();
		} catch (Exception e) {
			// Handle exception appropriately or log it
			e.printStackTrace();
			return null;
		}
	}

	public static void setText(By by, String value, String elementname) throws Exception {
        waitForElementVisible(by).sendKeys(value);
		Thread.sleep(2000);
        ExtentReportManager.info("Set text " + value + " on " + elementname.toString());
    }
	
	public static void navigateToUrl(String URL) {
        DriverManager.getDriver().navigate().to(URL);
        waitForPageLoaded();

        ExtentReportManager.pass("Navigate to URL: " + URL);


    }
}
