package zerocell;

import com.creditdatamw.zerocell.annotation.Column;

public class TestData {
	
	@Column(name = "TC", index = 0)
	private String testCase;

	@Column(name = "CaseID", index = 1)
	private String CaseID;
	
	@Column(name = "CaseName", index = 1)
	private String CaseName;
	
	@Column(name = "CaseOwner", index = 1)
	private String CaseOwner;

	public String getTestCase() {
		return testCase;
	}

	public String getUsername() {
		return CaseID;
	}

	public String getCaseName() {
		return CaseName;
	}

	public String getCaseOwner() {
		return CaseOwner;
	}

	@Override
	public String toString() {
		return "TestData [testCase=" + testCase + ", CaseID=" + CaseID + ", CaseName=" + CaseName + ", CaseOwner="
				+ CaseOwner + "]";
	}

}