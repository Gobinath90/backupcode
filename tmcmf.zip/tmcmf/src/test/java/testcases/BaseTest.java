package testcases;

import java.lang.reflect.Method;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;

import driver.DriverManager;
import enums.Browser;
import zerocell.ExcelReader;

public class BaseTest {

	protected void createDriver(Browser browser) {

		WebDriver driver;
		switch (browser) {
		case CHROME:
			driver = new ChromeDriver();
			break;
		case EDGE:
			driver = new EdgeDriver();
			break;
		case FIREFOX:
			driver = new FirefoxDriver();
			break;
		default:
			throw new IllegalArgumentException("Unsupported browser: " + browser);
		}

		DriverManager.setDriver(driver);
		DriverManager.getDriver().manage().window().maximize();
		DriverManager.getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}

	@AfterMethod(alwaysRun = true)
	public void closeDriver() {
		DriverManager.quitDriver();
	}

	@DataProvider
	public static Object[] getData(Method method) {
		return ExcelReader.getTestdatas().stream().filter(e -> e.getTestCase().equalsIgnoreCase(method.getName()))
				.toArray();
	}

}
