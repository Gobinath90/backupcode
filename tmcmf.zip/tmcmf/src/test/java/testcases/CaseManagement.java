package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import constants.FrameworkConstants;
import driver.DriverManager;
import enums.Browser;
import keywords.WebUI;
import report.ExtentReportManager;

public class CaseManagement extends BaseTest {

	@BeforeMethod
	public void setupWebDriver() {
		createDriver(Browser.CHROME);
		DriverManager.getDriver().get(FrameworkConstants.url);
		ExtentReportManager.initReports();
	}

	@Test(priority = 0, description = "Case File Data Location")
	public void VERTC_96() throws Exception {

		// Find all rows in the table body
		WebElement tableBody = DriverManager.getDriver().findElement(By.id("tbody"));
		java.util.List<WebElement> rows = tableBody.findElements(By.tagName("tr"));

		// Iterate through each row
		for (int i = 0; i < rows.size(); i++) {
			// Get the SessionId cell (last cell in the row)
			WebElement sessionIdCell = rows.get(i).findElements(By.tagName("td")).get(8);

			// Check if SessionId exists and is not null or empty
			if (!sessionIdCell.getText().trim().isEmpty()) {
				// Perform delete action based on row index i
				System.out.println("Deleting case in row " + (i + 1)); // Output can be changed to actual delete action

				// Example of how to find and click the delete button (assuming it's the second
				// button in the row)
				WebElement deleteButton = rows.get(i).findElements(By.tagName("button")).get(1);
				deleteButton.click();
				Thread.sleep(30000);
				try {
					WebUI.acceptAlert();
				} catch (Exception e) {
					// TODO: handle exception
				}

			} else {
				// SessionId is null or empty, skip delete action
				System.out.println("Skipping case in row " + (i + 1) + " because SessionId is empty");
			}
		}
	}
}
