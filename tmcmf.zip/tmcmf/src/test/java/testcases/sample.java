package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import driver.DriverManager;
import enums.Browser;
import keywords.WebUI;
import report.ExtentReportManager;

public class sample extends BaseTest {
	@BeforeMethod
	public void setupWebDriver() {
		createDriver(Browser.CHROME);
		DriverManager.getDriver().get("https://odp.qa.aws.etana.com/");
		ExtentReportManager.initReports();
	}

	@Test()
	public void name() throws Exception {
		Thread.sleep(10000);
		WebUI.setText(By.xpath("//label[text()='Email']/following-sibling::input"), "admin_gobi@etana.com", "Email");
		WebUI.setText(By.xpath("//label[@for='password']/following-sibling::input[1]"), "!Etana123", "Password");
		WebUI.Click(By.xpath("//input[@type='submit']"), "Submit Button");		
		Thread.sleep(8000);

		// Execute JavaScript to interact with the Shadow DOM element
		JavascriptExecutor js = (JavascriptExecutor) DriverManager.getDriver();
		js.executeScript(
				"document.querySelector('flt-glass-pane').shadowRoot.querySelector('flt-semantics-placeholder').click()");
		System.out.println("Enter Javascript code ");

		Thread.sleep(2000);
		WebUI.navigateToUrl("https://odp.qa.aws.etana.com/news-notifications");
		
		Thread.sleep(5000);
		WebUI.Click(By.id("flt-semantic-node-17"), "Add Button");		

		Thread.sleep(5000);


		WebUI.Click(By.xpath("//flt-semantics[@role='button']"), "Profile Icon");		
		WebUI.Click(By.xpath("//flt-semantics[@aria-label='Logout']"), "Logout");		


		Thread.sleep(2000);
		


	}
}
