package testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import constants.FrameworkConstants;
import driver.DriverManager;
import enums.Browser;
import keywords.WebUI;
import report.ExtentReportManager;

public class General extends BaseTest {

	private By version = By.xpath("//p[contains(text(), 'Version')]");
	private By udi = By.xpath("//p[contains(text(), 'UDI')]");
	private By planName = By.xpath("(//menu[contains(@class,'tabBorder flex')])[1]//button");
	private By activePlanName = By
			.xpath("(//menu[contains(@class, 'tabBorder flex')])[1]//button[contains(@class, 'font-bold')]");
	private By designName = By.xpath("(//div[@class='tabHeight']//menu)[2]");
	private By sideMenuEnabled = By.xpath("//section[contains(@class,'flex flex-col')]//button");
	private By sideMenuDisabled = By.xpath("//button[contains(@class, 'cursor-not-allowed')]");
	private By activeSideMenuTab = By
			.xpath("//img[contains(@class, 'bg-cblue-light')]/following-sibling::div/p[@class='']");
	private By caseId = By.xpath("//div[@class='caseId_div']//span[1]");
	private By emulator = By.xpath("//h1[text()='CMS EMULATOR']");
	private By header = By.xpath("//thead[@class='text-center']//tr[1]");
	private By aboutIcon = By.xpath("//img[@alt='About']");
	private By renderViewIconClose = By.xpath("//button[contains(@class,'renderViewTayerIcon bg-gray-icon')]");
	private By switchView = By.xpath("//button[@data-testid='switchViewer']//p[1]");
	private By switch3DViewer = By.xpath("//button[@data-testid='switch3DViewer']");
	private By renderViewIconOpen = By.xpath("//button[contains(@class,'renderViewTayerIcon bg-ligh-blue')]");

	@BeforeMethod
	public void setupWebDriver() {
		createDriver(Browser.CHROME);
		DriverManager.getDriver().get(FrameworkConstants.url);
		ExtentReportManager.initReports();
	}

	@Test(priority = 0, description = "Case File Data Location")
	public void VERTC_96() throws Exception {

		String dynamicValue = "8031";
		String elementName = "Handle Windows";
		By rowDetails = By.xpath(String.format("//tr[.//td[contains(@id, '%s')]]", dynamicValue));
		By CaseName = By.xpath(String.format("//td[@id='%s_casename']", dynamicValue));
		By launchCase = By.xpath(String.format("//button[@id='%s_launchCaseBtn']", dynamicValue));
		By deleteCase = By
				.xpath(String.format("//button[@id='%s_launchCaseBtn']/following-sibling::button", dynamicValue));

		WebElement caseNameElement = DriverManager.getDriver().findElement(CaseName);
		String caseNameTest = caseNameElement.getText();

		WebUI.getListElementsText(emulator, "CMS EMULATOR", true, "");
		WebUI.getListElementsText(header, "Header Name", true, "");
		WebUI.getListElementsText(rowDetails, "List of rows", true, "");
		WebUI.Click(launchCase, "Launch Case Button");

		// Handle window switching
		WebUI.handleWindows(elementName);

		// Continue with actions in the new window
		WebUI.getListElementsText(caseId, "Case ID:", true, dynamicValue);
		WebUI.getListElementsText(CaseName, "Case Name:", true, caseNameTest);

		// Close the new window/tab
		WebUI.closeOriginalWindow();

		// Switch back to the main/original window
		WebUI.switchBackToMainWindow(elementName);

		// Example: Click on another button in the new window
		WebUI.Click(deleteCase, "Delete Case Button");
	}

	@Test(priority = 1, description = "Review Multiple Plan Options")
	public void VERTC_98() throws Exception {

		String dynamicValue = "8029";
		String elementName = "Handle Windows";
		By CaseName = By.xpath(String.format("//td[@id='%s_casename']", dynamicValue));
		By launchCase = By.xpath(String.format("//button[@id='%s_launchCaseBtn']", dynamicValue));
		By deleteCase = By
				.xpath(String.format("//button[@id='%s_launchCaseBtn']/following-sibling::button", dynamicValue));
		WebElement caseNameElement = DriverManager.getDriver().findElement(CaseName);
		String caseNameTest = caseNameElement.getText();
		WebUI.Click(launchCase, "Launch Case Button");

		// Handle window switching
		WebUI.handleWindows(elementName);

		// Continue with actions in the new window
		WebUI.getListElementsText(caseId, "Case ID:", true, dynamicValue);
		WebUI.getListElementsText(CaseName, "Case Name:", true, caseNameTest);

		// Switch to the iframe using its name or ID
		DriverManager.getDriver().switchTo().frame("iframecontainer");

		WebUI.getCommaSeparatedElementText(planName, "Get Full Plan Name Text", true, "");
		WebUI.getCommaSeparatedElementText(activePlanName, "Initial Active Plane Name Text", true, "");

		List<WebElement> planNameElements = DriverManager.getDriver().findElements(planName);

		for (WebElement planNameElement : planNameElements) {
			// String planNameText = planNameElement.getText();
			// System.out.println("Plan Name Text: " + planNameText); // Print the text

			planNameElement.click();
			Thread.sleep(10000);
			WebUI.getCommaSeparatedElementText(activePlanName, "Switch to Another Plane Name", true, "");

		}

		Thread.sleep(2000);

		// If done with operations in iframe, switch back to default content
		DriverManager.getDriver().switchTo().defaultContent();

		// Close the new window/tab
		WebUI.closeOriginalWindow();

		// Switch back to the main/original window
		WebUI.switchBackToMainWindow(elementName);

		// Example: Click on another button in the new window
		WebUI.Click(deleteCase, "Delete Case Button");

	}

	@Test(priority = 2, description = "SRT Launch")
	public void VERTC_311() throws Exception {

		String dynamicValue = "8031";
		String elementName = "Handle Windows";
		String name ="//td[@id='%s_casename']";
		By CaseName = By.xpath(String.format(name, dynamicValue));
		By launchCase = By.xpath(String.format("//button[@id='%s_launchCaseBtn']", dynamicValue));
		By deleteCase = By
				.xpath(String.format("//button[@id='%s_launchCaseBtn']/following-sibling::button", dynamicValue));

		WebElement caseNameElement = DriverManager.getDriver().findElement(CaseName);
		String caseNameTest = caseNameElement.getText();

		WebUI.Click(launchCase, "Launch Case Button");

		// Handle window switching
		WebUI.handleWindows(elementName);

		// Continue with actions in the new window
		WebUI.getListElementsText(caseId, "Case ID:", true, dynamicValue);
		WebUI.getListElementsText(CaseName, "Case Name:", true, caseNameTest);
		// Switch to the iframe using its name or ID
		DriverManager.getDriver().switchTo().frame("iframecontainer");

		WebUI.getCommaSeparatedElementText(activePlanName, "Initial Active Plane Name Text", true, "");
		Thread.sleep(2000);

		// If done with operations in iframe, switch back to default content
		DriverManager.getDriver().switchTo().defaultContent();

		// Close the new window/tab
		WebUI.closeOriginalWindow();

		// Switch back to the main/original window
		WebUI.switchBackToMainWindow(elementName);

		// Example: Click on another button in the new window
		WebUI.Click(deleteCase, "Delete Case Button");
	}

	@Test(priority = 3, description = "Revision Label")
	public void VERTC_234() throws Exception {

		String dynamicValue = "8031";
		String elementName = "Handle Windows";
		By CaseName = By.xpath(String.format("//td[@id='%s_casename']", dynamicValue));
		By launchCase = By.xpath(String.format("//button[@id='%s_launchCaseBtn']", dynamicValue));
		By deleteCase = By
				.xpath(String.format("//button[@id='%s_launchCaseBtn']/following-sibling::button", dynamicValue));
		WebElement caseNameElement = DriverManager.getDriver().findElement(CaseName);
		String caseNameTest = caseNameElement.getText();
		WebUI.Click(launchCase, "Launch Case Button");

		// Handle window switching
		WebUI.handleWindows(elementName);

		// Continue with actions in the new window
		WebUI.getListElementsText(caseId, "Case ID:", true, dynamicValue);
		WebUI.getListElementsText(CaseName, "Case Name:", true, caseNameTest);

		// Switch to the iframe using its name or ID
		DriverManager.getDriver().switchTo().frame("iframecontainer");
		WebUI.getListElementsText(activePlanName, "Active Plane Name Text", true, "");

		WebUI.Click(aboutIcon, " About Icon");
		WebUI.getListElementsText(version, "Version", true, "2.2");

		Thread.sleep(2000);
		// If done with operations in iframe, switch back to default content
		DriverManager.getDriver().switchTo().defaultContent();

		// Close the new window/tab
		WebUI.closeOriginalWindow();

		// Switch back to the main/original window
		WebUI.switchBackToMainWindow(elementName);

		// Example: Click on another button in the new window
		WebUI.Click(deleteCase, "Delete Case Button");
		Thread.sleep(10000);

	}
	@Test(priority = 4, description = "UDI Label")
	public void VERTC_312() throws Exception {

		String dynamicValue = "8031";
		String elementName = "Handle Windows";
		By CaseName = By.xpath(String.format("//td[@id='%s_casename']", dynamicValue));
		By launchCase = By.xpath(String.format("//button[@id='%s_launchCaseBtn']", dynamicValue));
		By deleteCase = By
				.xpath(String.format("//button[@id='%s_launchCaseBtn']/following-sibling::button", dynamicValue));
		WebElement caseNameElement = DriverManager.getDriver().findElement(CaseName);
		String caseNameTest = caseNameElement.getText();
		WebUI.Click(launchCase, "Launch Case Button");

		// Handle window switching
		WebUI.handleWindows(elementName);

		// Continue with actions in the new window
		WebUI.getListElementsText(caseId, "Case ID:", true, dynamicValue);
		WebUI.getListElementsText(CaseName, "Case Name:", true, caseNameTest);

		// Switch to the iframe using its name or ID
		DriverManager.getDriver().switchTo().frame("iframecontainer");
		WebUI.getListElementsText(activePlanName, "Active Plane Name Text", true, "");

		WebUI.Click(aboutIcon, " About Icon");
		WebUI.getListElementsText(udi, "UDI", true, "");


		Thread.sleep(2000);
		// If done with operations in iframe, switch back to default content
		DriverManager.getDriver().switchTo().defaultContent();

		// Close the new window/tab
		WebUI.closeOriginalWindow();

		// Switch back to the main/original window
		WebUI.switchBackToMainWindow(elementName);

		// Example: Click on another button in the new window
		WebUI.Click(deleteCase, "Delete Case Button");
		Thread.sleep(10000);

	}
	// @Test(description ="Revision Label")
	public void AboutIcon() throws Exception {

		String dynamicValue = "8031";
		String elementName = "Handle Windows";
		By CaseName = By.xpath(String.format("//td[@id='%s_casename']", dynamicValue));
		By launchCase = By.xpath(String.format("//button[@id='%s_launchCaseBtn']", dynamicValue));
		By deleteCase = By
				.xpath(String.format("//button[@id='%s_launchCaseBtn']/following-sibling::button", dynamicValue));
		WebElement caseNameElement = DriverManager.getDriver().findElement(CaseName);
		String caseNameTest = caseNameElement.getText();
		WebUI.Click(launchCase, "Launch Case Button");

		// Handle window switching
		WebUI.handleWindows(elementName);

		// Continue with actions in the new window
		WebUI.getListElementsText(caseId, "Case ID:", true, dynamicValue);
		WebUI.getListElementsText(CaseName, "Case Name:", true, caseNameTest);

		// Switch to the iframe using its name or ID
		DriverManager.getDriver().switchTo().frame("iframecontainer");

		WebUI.Click(aboutIcon, " About Icon");
		WebUI.getListElementsText(version, "Version", true, "2.2");
		WebUI.getListElementsText(udi, "UDI", true, "");
		WebUI.getListElementsText(planName, "Plan Name Text", true, "");
		WebUI.getListElementsText(activePlanName, "Active Plane Name Text", true, "");
		WebUI.getListElementsText(designName, "Design Name Text", true, "");
		WebUI.getListElementsText(sideMenuEnabled, "Side Menu Name Enabled", true, "");
		WebUI.getListElementsText(sideMenuDisabled, "Side Menu Disabled", true, "");
		WebUI.getListElementsText(activeSideMenuTab, "Active side Menu TAB", true, "");
		Thread.sleep(2000);

		// Check if the 'OPEN VCP' button is present before clicking
		if (WebUI.verifyElementPresent(renderViewIconClose, "Open VCP")) {
			WebUI.Click(renderViewIconClose, "OPEN VCP");
			Thread.sleep(3000);
			// Check if the 2D Slice View button is present and click it
			if (WebUI.verifyElementPresent(switchView, "2D Slice View")) {
				WebUI.Click(switch3DViewer, "3D View");

				// Perform camera position clicks
				clickCameraPosition("topCameraPosition", "TOP Camera");
				clickCameraPosition("leftCameraPosition", "LEFT Camera");
				clickCameraPosition("rightCameraPosition", "RIGHT Camera");
				clickCameraPosition("bottomCameraPosition", "BOTTOM Camera");
				clickCameraPosition("pCameraPositio", "POSTERIOR Camera");
				clickCameraPosition("faceCameraPosition", "NHP Camera");

				// Close VCP after completing actions
				WebUI.Click(renderViewIconOpen, "Close VCP");
				Thread.sleep(3000);
			} else {
				System.out.println("2D Slice View button not found. Skipping camera position actions.");
			}
		} else {
			System.out.println("OPEN VCP button not found. Skipping VCP interaction.");
		}

		// If done with operations in iframe, switch back to default content
		DriverManager.getDriver().switchTo().defaultContent();

		// Close the new window/tab
		WebUI.closeOriginalWindow();

		// Switch back to the main/original window
		WebUI.switchBackToMainWindow(elementName);

		// Example: Click on another button in the new window
		WebUI.Click(deleteCase, "Delete Case Button");

	}

	private void clickCameraPosition(String altAttribute, String cameraName) throws Exception {
		WebUI.Click(By.xpath("//img[@alt='" + altAttribute + "']"), cameraName);
		Thread.sleep(3000);
	}

}
