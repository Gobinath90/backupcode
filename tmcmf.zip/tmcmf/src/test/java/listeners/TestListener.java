package listeners;

import static constants.FrameworkConstants.BOLD_END;
import static constants.FrameworkConstants.BOLD_START;
import static constants.FrameworkConstants.ICON_BUG;
import static constants.FrameworkConstants.ICON_Navigate_Right;
import static constants.FrameworkConstants.ICON_SMILEY_FAIL;
import static constants.FrameworkConstants.ICON_SMILEY_PASS;

import java.io.IOException;
import java.util.Arrays;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import annotations.FrameworkAnnotation;
import constants.FrameworkConstants;
import enums.AuthorType;
import enums.CategoryType;
import helpers.PropertiesHelpers;
import report.ExtentReportManager;
import utils.BrowserOSInfoUtils;
import utils.IconUtils;

public class TestListener implements ITestListener, ISuiteListener, IInvokedMethodListener {
	static int count_totalTCs;
	static int count_passedTCs;
	static int count_skippedTCs;
	static int count_failedTCs;

	public String getTestName(ITestResult result) {
		return result.getTestName() != null ? result.getTestName()
				: result.getMethod().getConstructorOrMethod().getName();
	}

	public String getTestDescription(ITestResult result) {
		return result.getMethod().getDescription() != null ? result.getMethod().getDescription() : getTestName(result);
	}

	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
	}

	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
	}

	@Override
	public void onStart(ISuite iSuite) {
		System.out.println("********** RUN STARTED **********");
		
		PropertiesHelpers.loadAllFiles();

		ExtentReportManager.initReports();
	}

	@Override
	public void onFinish(ISuite iSuite) {
		System.out.println("********** RUN FINISHED **********");
		System.out.println("=====> End Suite: " + iSuite.getName());
		try {
			ExtentReportManager.flushReports();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Override
	public void onTestStart(ITestResult iTestResult) {
		System.out.println("Test case: " + getTestName(iTestResult) + " is starting...");
		count_totalTCs = count_totalTCs + 1;

		ExtentReportManager.createTest(iTestResult.getName());
		ExtentReportManager.addAuthors(getAuthorType(iTestResult));
		ExtentReportManager.addCategories(getCategoryType(iTestResult));
		ExtentReportManager.addDevices();

		ExtentReportManager.info("<b>" + IconUtils.getOSIcon() + "  &  " + IconUtils.getBrowserIcon() + " --------- "
				+ BrowserOSInfoUtils.getOS_Browser_BrowserVersionInfo() + "</b>");
        
		String url=FrameworkConstants.url;
		ExtentReportManager.info(ICON_Navigate_Right + "  Navigating to : <a href=" + url + "><b>" + url + "</b></a>");

	}

	@Override
	public void onTestSuccess(ITestResult iTestResult) {
		System.out.println("Test case: " + getTestName(iTestResult) + " is passed.");
		count_passedTCs = count_passedTCs + 1;
		String logText = "<b>" + iTestResult.getMethod().getMethodName() + " is passed.</b>" + "  " + ICON_SMILEY_PASS;
		Markup markup_message = MarkupHelper.createLabel(logText, ExtentColor.GREEN);
		ExtentReportManager.pass(markup_message);
	}

	@Override
	public void onTestFailure(ITestResult iTestResult) {
//		System.out.println("FAILED !! Test case " + getTestName(iTestResult) + " is failed.");
//		System.out.println(iTestResult.getThrowable());

		count_failedTCs = count_failedTCs + 1;
		ExtentReportManager.fail(ICON_BUG + "  " + "<b><i>" + iTestResult.getThrowable().toString() + "</i></b>");
		String exceptionMessage = Arrays.toString(iTestResult.getThrowable().getStackTrace());
		String message = "<details><summary><b><font color=red> Exception occured, click to see details: "
				+ ICON_SMILEY_FAIL + " </font></b>" + "</summary>" + exceptionMessage.replaceAll(",", "<br>")
				+ "</details> \n";
		ExtentReportManager.fail(message);

		String logText = BOLD_START + iTestResult.getMethod().getMethodName() + " is failed." + BOLD_END + "  "
				+ ICON_SMILEY_FAIL;
		Markup markup_message = MarkupHelper.createLabel(logText, ExtentColor.RED);

		ExtentReportManager.fail(markup_message);

	}

	@Override
	public void onTestSkipped(ITestResult iTestResult) {
		System.out.println("WARNING!! Test case: " + getTestName(iTestResult) + " is skipped.");
		count_skippedTCs = count_skippedTCs + 1;
		
		ExtentReportManager.skip(ICON_BUG + "  " + "<b><i>" + iTestResult.getThrowable().toString() + "</i></b>");
		// ExtentLogger.skip("<b><i>" + result.getThrowable().toString() + "</i></b>");
		String logText = "<b>" + iTestResult.getMethod().getMethodName() + " is skipped.</b>" + "  " + ICON_SMILEY_FAIL;
		Markup markup_message = MarkupHelper.createLabel(logText, ExtentColor.YELLOW);
		ExtentReportManager.skip(markup_message);
		
		

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult iTestResult) {
		ExtentReportManager.logMessage("Test failed but it is in defined success ratio: " + getTestName(iTestResult));
	}

	public AuthorType[] getAuthorType(ITestResult iTestResult) {
		if (iTestResult.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(FrameworkAnnotation.class) == null) {
			return null;
		}
		AuthorType authorType[] = iTestResult.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(FrameworkAnnotation.class).author();
		return authorType;
	}

	public CategoryType[] getCategoryType(ITestResult iTestResult) {
		if (iTestResult.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(FrameworkAnnotation.class) == null) {
			return null;
		}
		CategoryType categoryType[] = iTestResult.getMethod().getConstructorOrMethod().getMethod()
				.getAnnotation(FrameworkAnnotation.class).category();
		return categoryType;
	}

}
